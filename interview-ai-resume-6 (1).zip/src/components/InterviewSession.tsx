import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { Volume2, Mic, MicOff, Play, Pause, CheckCircle, Lightbulb, ArrowRight } from 'lucide-react';

interface InterviewSessionProps {
  interviewType: string;
  resumeContent: string;
  onComplete: () => void;
}

const InterviewSession: React.FC<InterviewSessionProps> = ({ interviewType, resumeContent, onComplete }) => {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [isListening, setIsListening] = useState(false);
  const [userAnswer, setUserAnswer] = useState('');
  const [isAnswered, setIsAnswered] = useState(false);
  const [feedback, setFeedback] = useState<{rating: number, comment: string} | null>(null);
  const [optimalAnswer, setOptimalAnswer] = useState('');
  const [showOptimal, setShowOptimal] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);

  const questions = [
    "Explain the concept of Object-Oriented Programming in Java.",
    "What is the difference between ArrayList and LinkedList?",
    "How do you handle exceptions in Java?",
    "Explain the concept of inheritance and polymorphism.",
    "What are design patterns? Give an example."
  ];

  const speakText = (text: string) => {
    if ('speechSynthesis' in window) {
      setIsSpeaking(true);
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.onend = () => setIsSpeaking(false);
      speechSynthesis.speak(utterance);
    }
  };

  const startListening = () => {
    setIsListening(true);
    // Simulate speech recognition
    setTimeout(() => {
      setUserAnswer('This is a simulated answer from speech recognition.');
      setIsListening(false);
    }, 3000);
  };

  const submitAnswer = () => {
    setIsAnswered(true);
  };

  const verifyAnswer = () => {
    // Simulate AI verification
    const rating = Math.floor(Math.random() * 4) + 7; // 7-10 rating
    const comments = [
      'Good explanation with clear understanding.',
      'Excellent answer covering all key points.',
      'Solid response, could add more examples.',
      'Very comprehensive answer.'
    ];
    setFeedback({
      rating,
      comment: comments[Math.floor(Math.random() * comments.length)]
    });
  };

  const showOptimalAnswer = () => {
    const optimal = 'Object-Oriented Programming (OOP) is a programming paradigm based on the concept of objects, which contain data and code. The four main principles are: Encapsulation, Inheritance, Polymorphism, and Abstraction.';
    setOptimalAnswer(optimal);
    setShowOptimal(true);
    speakText(optimal);
  };

  const nextQuestion = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setUserAnswer('');
      setIsAnswered(false);
      setFeedback(null);
      setShowOptimal(false);
      setOptimalAnswer('');
    } else {
      onComplete();
    }
  };

  const getRatingEmoji = (rating: number) => {
    if (rating >= 8) return '😊';
    if (rating >= 6) return '😐';
    return '😞';
  };

  return (
    <div className="min-h-screen bg-black relative overflow-hidden">
      {/* Background effects */}
      <div className="absolute top-20 left-20 w-96 h-96 bg-green-500/10 rounded-full blur-3xl animate-pulse"></div>
      <div className="absolute bottom-20 right-20 w-80 h-80 bg-green-400/10 rounded-full blur-3xl animate-pulse" style={{animationDelay: '1s'}}></div>
      
      <div className="relative z-10 max-w-4xl mx-auto px-4 py-12">
        <div className="text-center mb-8">
          <h1 className="brand-text text-4xl mb-4">CareerCortex</h1>
          <p className="dynamic-text text-gray-300">Question {currentQuestion + 1} of {questions.length}</p>
        </div>

        <Card className="bg-gray-900/80 backdrop-blur-lg border-green-500/30 shadow-2xl mb-6">
          <CardHeader>
            <CardTitle className="dynamic-text text-xl text-white flex items-center justify-between">
              Interview Question
              <Button
                onClick={() => speakText(questions[currentQuestion])}
                variant="ghost"
                size="sm"
                className="text-green-400 hover:text-green-300"
                disabled={isSpeaking}
              >
                {isSpeaking ? <Pause className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
              </Button>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="dynamic-text text-gray-300 text-lg mb-4">{questions[currentQuestion]}</p>
            
            <div className="space-y-4">
              <Textarea
                value={userAnswer}
                onChange={(e) => setUserAnswer(e.target.value)}
                placeholder="Your answer will appear here when you speak or you can type..."
                className="bg-gray-800/50 border-green-500/30 text-white min-h-32"
              />
              
              <div className="flex gap-3">
                {!isAnswered ? (
                  <>
                    <Button
                      onClick={isListening ? () => setIsListening(false) : startListening}
                      className={`flex-1 ${isListening ? 'bg-red-600 hover:bg-red-500' : 'bg-blue-600 hover:bg-blue-500'} text-white`}
                    >
                      {isListening ? <MicOff className="w-4 h-4 mr-2" /> : <Mic className="w-4 h-4 mr-2" />}
                      {isListening ? 'Stop Recording' : 'Start Recording'}
                    </Button>
                    <Button
                      onClick={submitAnswer}
                      disabled={!userAnswer.trim()}
                      className="flex-1 bg-green-600 hover:bg-green-500 text-white"
                    >
                      Submit Answer
                    </Button>
                  </>
                ) : (
                  <div className="flex gap-3 w-full">
                    <Button onClick={verifyAnswer} className="flex-1 bg-purple-600 hover:bg-purple-500 text-white">
                      <CheckCircle className="w-4 h-4 mr-2" />
                      Verify Answer
                    </Button>
                    <Button onClick={showOptimalAnswer} className="flex-1 bg-yellow-600 hover:bg-yellow-500 text-white">
                      <Lightbulb className="w-4 h-4 mr-2" />
                      Optimal Answer
                    </Button>
                    <Button onClick={nextQuestion} className="flex-1 bg-green-600 hover:bg-green-500 text-white">
                      <ArrowRight className="w-4 h-4 mr-2" />
                      Next
                    </Button>
                  </div>
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        {feedback && (
          <Card className="bg-gray-900/80 backdrop-blur-lg border-purple-500/30 shadow-2xl mb-6">
            <CardContent className="pt-6">
              <div className="text-center">
                <div className="text-4xl mb-2">{getRatingEmoji(feedback.rating)}</div>
                <h3 className="dynamic-text text-xl text-white mb-2">Rating: {feedback.rating}/10</h3>
                <p className="dynamic-text text-gray-300">{feedback.comment}</p>
              </div>
            </CardContent>
          </Card>
        )}

        {showOptimal && (
          <Card className="bg-gray-900/80 backdrop-blur-lg border-yellow-500/30 shadow-2xl">
            <CardHeader>
              <CardTitle className="dynamic-text text-xl text-white flex items-center">
                <Lightbulb className="w-5 h-5 mr-2 text-yellow-400" />
                Optimal Answer
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="dynamic-text text-gray-300">{optimalAnswer}</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
};

export default InterviewSession;