import React from 'react';
import AuthManager from './AuthManager';

const AppLayout: React.FC = () => {
  return (
    <div className="min-h-screen">
      <AuthManager />
    </div>
  );
};

export default AppLayout;