import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Upload, FileText, Brain, Users, Code } from 'lucide-react';

interface ResumeUploadProps {
  onInterviewTypeSelect: (type: string, resumeContent: string) => void;
}

const ResumeUpload: React.FC<ResumeUploadProps> = ({ onInterviewTypeSelect }) => {
  const [resumeFile, setResumeFile] = useState<File | null>(null);
  const [isUploaded, setIsUploaded] = useState(false);
  const [resumeContent, setResumeContent] = useState('');

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setResumeFile(file);
      // Simulate resume content extraction
      const mockContent = `Skills: Java, Python, React, Node.js\nExperience: 3 years software development\nEducation: Computer Science`;
      setResumeContent(mockContent);
      setIsUploaded(true);
    }
  };

  const interviewTypes = [
    {
      id: 'technical',
      title: 'Technical Interview',
      description: 'Programming, algorithms, and technical skills',
      icon: Code,
      color: 'text-blue-400'
    },
    {
      id: 'hr',
      title: 'HR Interview', 
      description: 'Behavioral questions and soft skills',
      icon: Users,
      color: 'text-green-400'
    },
    {
      id: 'testcase',
      title: 'Test Case Interview',
      description: 'Problem-solving and analytical thinking',
      icon: Brain,
      color: 'text-purple-400'
    }
  ];

  return (
    <div className="min-h-screen bg-black relative overflow-hidden">
      {/* Background effects */}
      <div className="absolute top-20 left-20 w-96 h-96 bg-green-500/10 rounded-full blur-3xl animate-pulse"></div>
      <div className="absolute bottom-20 right-20 w-80 h-80 bg-green-400/10 rounded-full blur-3xl animate-pulse" style={{animationDelay: '1s'}}></div>
      
      <div className="relative z-10 max-w-4xl mx-auto px-4 py-12">
        <div className="text-center mb-12">
          <h1 className="brand-text text-4xl mb-4">CareerCortex</h1>
          <p className="dynamic-text text-gray-300 text-lg">AI-Powered Interview Preparation</p>
        </div>

        {!isUploaded ? (
          <Card className="bg-gray-900/80 backdrop-blur-lg border-green-500/30 shadow-2xl">
            <CardHeader>
              <CardTitle className="dynamic-text text-2xl text-white flex items-center justify-center">
                <Upload className="w-6 h-6 mr-2 text-green-400" />
                Upload Your Resume
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Label htmlFor="resume" className="dynamic-text text-gray-300">Select Resume File</Label>
              <Input
                id="resume"
                type="file"
                accept=".pdf,.doc,.docx"
                onChange={handleFileUpload}
                className="bg-gray-800/50 border-green-500/30 text-white file:bg-green-600 file:text-white file:border-0 file:rounded-md file:px-4 file:py-2"
              />
              {resumeFile && (
                <div className="flex items-center space-x-2 text-green-400">
                  <FileText className="w-4 h-4" />
                  <span className="dynamic-text text-sm">{resumeFile.name}</span>
                </div>
              )}
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-8">
            <div className="text-center">
              <h2 className="dynamic-text text-2xl text-white mb-4">Choose Interview Type</h2>
              <p className="dynamic-text text-gray-300">Select the type of interview you want to practice</p>
            </div>
            
            <div className="grid md:grid-cols-3 gap-6">
              {interviewTypes.map((type) => {
                const IconComponent = type.icon;
                return (
                  <Card 
                    key={type.id}
                    className="bg-gray-900/80 backdrop-blur-lg border-green-500/30 hover:border-green-400/50 transition-all duration-300 cursor-pointer transform hover:scale-105"
                    onClick={() => onInterviewTypeSelect(type.id, resumeContent)}
                  >
                    <CardHeader className="text-center">
                      <IconComponent className={`w-12 h-12 mx-auto mb-4 ${type.color}`} />
                      <CardTitle className="dynamic-text text-xl text-white">{type.title}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="dynamic-text text-gray-300 text-center text-sm">{type.description}</p>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ResumeUpload;