import React, { useState } from 'react';
import GetStartedPage from './GetStartedPage';
import SignInForm from './SignInForm';
import SignUpForm from './SignUpForm';
import OtpVerification from './OtpVerification';
import Dashboard from './Dashboard';
import { useToast } from '@/hooks/use-toast';

type AuthState = 'getstarted' | 'signin' | 'signup' | 'otp' | 'dashboard';

interface UserData {
  name: string;
  email: string;
  phone: string;
  username?: string;
}

const AuthManager: React.FC = () => {
  const [authState, setAuthState] = useState<AuthState>('getstarted');
  const [userData, setUserData] = useState<UserData | null>(null);
  const [generatedOtp, setGeneratedOtp] = useState('');
  const { toast } = useToast();

  const handleGetStarted = () => {
    setAuthState('signin');
  };

  const handleSignIn = (username: string, password: string) => {
    if (username && password) {
      setUserData({ name: username, email: '', phone: '', username });
      setAuthState('dashboard');
      toast({
        title: 'Welcome back!',
        description: 'You have successfully signed in.',
      });
    }
  };

  const handleSignUp = (formData: any) => {
    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    setGeneratedOtp(otp);
    setUserData({
      name: formData.name,
      email: formData.email,
      phone: formData.phone
    });
    
    toast({
      title: 'OTP Sent!',
      description: `Verification code sent to ${formData.phone}. Code: ${otp}`,
    });
    
    setAuthState('otp');
  };

  const handleOtpVerify = (otp: string) => {
    if (otp === generatedOtp) {
      setAuthState('dashboard');
      toast({
        title: 'Account Created!',
        description: 'Your account has been successfully created.',
      });
    } else {
      toast({
        title: 'Invalid OTP',
        description: 'Please enter the correct verification code.',
        variant: 'destructive'
      });
    }
  };

  const handleResendOtp = () => {
    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    setGeneratedOtp(otp);
    toast({
      title: 'OTP Resent!',
      description: `New verification code: ${otp}`,
    });
  };

  const handleLogout = () => {
    setAuthState('getstarted');
    setUserData(null);
    setGeneratedOtp('');
    toast({
      title: 'Logged out',
      description: 'You have been successfully logged out.',
    });
  };

  switch (authState) {
    case 'getstarted':
      return <GetStartedPage onGetStarted={handleGetStarted} />;
    case 'signin':
      return (
        <SignInForm 
          onSignIn={handleSignIn}
          onShowSignUp={() => setAuthState('signup')}
        />
      );
    case 'signup':
      return (
        <SignUpForm 
          onSignUp={handleSignUp}
          onShowSignIn={() => setAuthState('signin')}
        />
      );
    case 'otp':
      return (
        <OtpVerification 
          onVerify={handleOtpVerify}
          onResend={handleResendOtp}
          phone={userData?.phone || ''}
        />
      );
    case 'dashboard':
      return (
        <Dashboard 
          username={userData?.name || userData?.username || 'User'}
          onLogout={handleLogout}
        />
      );
    default:
      return null;
  }
};

export default AuthManager;