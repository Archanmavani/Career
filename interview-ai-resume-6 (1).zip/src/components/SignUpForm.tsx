import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

interface SignUpFormProps {
  onSignUp: (formData: any) => void;
  onShowSignIn: () => void;
}

const countryCodes = [
  { code: '+1', country: 'US/CA' },
  { code: '+44', country: 'UK' },
  { code: '+91', country: 'India' },
  { code: '+86', country: 'China' },
  { code: '+49', country: 'Germany' },
  { code: '+33', country: 'France' },
  { code: '+81', country: 'Japan' },
];

const SignUpForm: React.FC<SignUpFormProps> = ({ onSignUp, onShowSignIn }) => {
  const [formData, setFormData] = useState({
    name: '',
    dob: '',
    email: '',
    countryCode: '+1',
    phoneNumber: '',
    password: '',
    confirmPassword: ''
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const validatePassword = (password: string) => {
    const minLength = password.length >= 8;
    const hasUpper = /[A-Z]/.test(password);
    const hasLower = /[a-z]/.test(password);
    const hasNumber = /\d/.test(password);
    const hasSpecial = /[!@#$%^&*(),.?":{}|<>]/.test(password);
    
    return minLength && hasUpper && hasLower && hasNumber && hasSpecial;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newErrors: Record<string, string> = {};

    if (!validatePassword(formData.password)) {
      newErrors.password = 'Password must be 8+ chars with uppercase, lowercase, number, and special character';
    }
    if (formData.password !== formData.confirmPassword) {
      newErrors.confirmPassword = 'Passwords do not match';
    }
    if (!formData.phoneNumber) {
      newErrors.phoneNumber = 'Phone number is required';
    }

    setErrors(newErrors);
    if (Object.keys(newErrors).length === 0) {
      onSignUp({
        ...formData,
        phone: formData.countryCode + formData.phoneNumber
      });
    }
  };

  return (
    <div className="min-h-screen bg-black relative overflow-hidden flex items-center justify-center py-8">
      {/* Background glow effects */}
      <div className="absolute top-10 right-10 w-80 h-80 bg-green-500/20 rounded-full blur-3xl animate-pulse"></div>
      <div className="absolute bottom-10 left-10 w-72 h-72 bg-green-400/15 rounded-full blur-3xl animate-pulse" style={{animationDelay: '1s'}}></div>
      <div className="absolute top-1/2 left-1/3 w-56 h-56 bg-green-300/10 rounded-full blur-2xl animate-ping"></div>
      <div className="absolute top-20 right-1/3 w-40 h-40 bg-green-600/12 rounded-full blur-xl animate-bounce" style={{animationDelay: '2s', animationDuration: '3s'}}></div>
      
      <Card className="w-full max-w-lg mx-4 bg-gray-900/80 backdrop-blur-lg border-green-500/30 shadow-2xl shadow-green-500/20">
        <CardHeader className="text-center">
          <CardTitle className="brand-text text-3xl mb-2">Create Account</CardTitle>
          <CardDescription className="dynamic-text text-green-300 text-lg">Join CareerCortex today</CardDescription>
        </CardHeader>
        
        <form onSubmit={handleSubmit}>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name" className="dynamic-text text-gray-300 font-medium">Full Name</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  className="bg-gray-800/50 border-green-500/30 text-white placeholder-gray-400 focus:border-green-500 focus:ring-green-500/20 transition-all duration-300"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="dob" className="dynamic-text text-gray-300 font-medium">Date of Birth</Label>
                <Input
                  id="dob"
                  type="date"
                  value={formData.dob}
                  onChange={(e) => setFormData({...formData, dob: e.target.value})}
                  className="bg-gray-800/50 border-green-500/30 text-white focus:border-green-500 focus:ring-green-500/20 transition-all duration-300"
                  required
                />
              </div>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="email" className="dynamic-text text-gray-300 font-medium">Email</Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({...formData, email: e.target.value})}
                className="bg-gray-800/50 border-green-500/30 text-white placeholder-gray-400 focus:border-green-500 focus:ring-green-500/20 transition-all duration-300"
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label className="dynamic-text text-gray-300 font-medium">Phone Number</Label>
              <div className="flex space-x-2">
                <Select value={formData.countryCode} onValueChange={(value) => setFormData({...formData, countryCode: value})}>
                  <SelectTrigger className="w-24 bg-gray-800/50 border-green-500/30 text-white focus:border-green-500">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-gray-800 border-green-500/30">
                    {countryCodes.map((country) => (
                      <SelectItem key={country.code} value={country.code} className="text-white hover:bg-gray-700">
                        {country.code}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Input
                  type="tel"
                  value={formData.phoneNumber}
                  onChange={(e) => setFormData({...formData, phoneNumber: e.target.value})}
                  className="flex-1 bg-gray-800/50 border-green-500/30 text-white placeholder-gray-400 focus:border-green-500 focus:ring-green-500/20 transition-all duration-300"
                  placeholder="Phone number"
                  required
                />
              </div>
              {errors.phoneNumber && <p className="text-red-400 text-sm">{errors.phoneNumber}</p>}
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="password" className="dynamic-text text-gray-300 font-medium">Password</Label>
              <Input
                id="password"
                type="password"
                value={formData.password}
                onChange={(e) => setFormData({...formData, password: e.target.value})}
                className="bg-gray-800/50 border-green-500/30 text-white placeholder-gray-400 focus:border-green-500 focus:ring-green-500/20 transition-all duration-300"
                required
              />
              {errors.password && <p className="text-red-400 text-sm">{errors.password}</p>}
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="confirmPassword" className="dynamic-text text-gray-300 font-medium">Confirm Password</Label>
              <Input
                id="confirmPassword"
                type="password"
                value={formData.confirmPassword}
                onChange={(e) => setFormData({...formData, confirmPassword: e.target.value})}
                className="bg-gray-800/50 border-green-500/30 text-white placeholder-gray-400 focus:border-green-500 focus:ring-green-500/20 transition-all duration-300"
                required
              />
              {errors.confirmPassword && <p className="text-red-400 text-sm">{errors.confirmPassword}</p>}
            </div>
          </CardContent>
          
          <CardFooter className="flex flex-col space-y-4">
            <Button 
              type="submit" 
              className="w-full bg-green-600 hover:bg-green-500 text-white font-semibold py-3 rounded-lg transition-all duration-300 transform hover:scale-105 hover:shadow-lg hover:shadow-green-500/50"
            >
              Create Account
            </Button>
            
            <div className="text-center">
              <span className="dynamic-text text-gray-400">Already have an account? </span>
              <button 
                type="button" 
                onClick={onShowSignIn}
                className="dynamic-text text-green-400 hover:text-green-300 font-medium transition-colors duration-200 hover:underline"
              >
                Sign In
              </button>
            </div>
          </CardFooter>
        </form>
      </Card>
    </div>
  );
};

export default SignUpForm;