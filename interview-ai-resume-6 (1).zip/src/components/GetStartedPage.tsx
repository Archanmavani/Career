import React from 'react';
import { Button } from '@/components/ui/button';

interface GetStartedPageProps {
  onGetStarted: () => void;
}

const GetStartedPage: React.FC<GetStartedPageProps> = ({ onGetStarted }) => {
  return (
    <div className="min-h-screen bg-black relative overflow-hidden flex items-center justify-center">
      {/* Enhanced background glow effects covering entire page */}
      <div className="absolute top-10 left-10 w-96 h-96 bg-green-500/30 rounded-full blur-3xl animate-pulse"></div>
      <div className="absolute bottom-10 right-10 w-80 h-80 bg-green-400/25 rounded-full blur-3xl animate-spin" style={{animationDuration: '20s'}}></div>
      <div className="absolute top-1/3 right-1/4 w-64 h-64 bg-green-300/20 rounded-full blur-2xl animate-bounce" style={{animationDuration: '3s'}}></div>
      <div className="absolute bottom-1/3 left-1/4 w-72 h-72 bg-green-600/15 rounded-full blur-3xl animate-pulse" style={{animationDelay: '2s'}}></div>
      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-green-400/10 rounded-full blur-3xl animate-spin" style={{animationDelay: '4s', animationDuration: '30s'}}></div>
      <div className="absolute top-20 right-1/3 w-32 h-32 bg-green-500/20 rounded-full blur-xl animate-pulse" style={{animationDelay: '1s'}}></div>
      <div className="absolute bottom-32 left-1/3 w-40 h-40 bg-green-300/25 rounded-full blur-2xl animate-bounce" style={{animationDelay: '3s', animationDuration: '4s'}}></div>
      <div className="absolute top-5 left-1/2 w-24 h-24 bg-green-400/30 rounded-full blur-lg animate-ping" style={{animationDelay: '2s'}}></div>
      <div className="absolute bottom-5 right-5 w-36 h-36 bg-green-500/15 rounded-full blur-2xl animate-pulse" style={{animationDelay: '5s'}}></div>
      
      {/* Main content */}
      <div className="relative z-10 text-center px-8">
        <h1 className="brand-text text-6xl md:text-8xl font-bold mb-4">
          CareerCortex
        </h1>
        <p className="dynamic-text text-xl md:text-2xl text-green-300 mb-8">
          AI-Powered Interview Assistant
        </p>
        <p className="dynamic-text text-lg text-gray-300 mb-12 max-w-2xl mx-auto">
          Upload your resume and get personalized interview questions powered by artificial intelligence
        </p>
        
        <Button 
          onClick={onGetStarted}
          className="px-12 py-6 text-xl font-semibold bg-green-600 hover:bg-green-500 text-white rounded-lg transition-all duration-300 hover:shadow-lg hover:shadow-green-500/50 hover:scale-105"
        >
          Get Started
        </Button>
      </div>
    </div>
  );
};

export default GetStartedPage;