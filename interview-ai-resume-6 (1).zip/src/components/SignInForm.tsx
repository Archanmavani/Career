import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';

interface SignInFormProps {
  onSignIn: (username: string, password: string) => void;
  onShowSignUp: () => void;
}

const SignInForm: React.FC<SignInFormProps> = ({ onSignIn, onShowSignUp }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSignIn(username, password);
  };

  return (
    <div className="min-h-screen bg-black relative overflow-hidden flex items-center justify-center">
      {/* Background glow effects */}
      <div className="absolute top-10 left-10 w-72 h-72 bg-green-500/20 rounded-full blur-3xl animate-pulse"></div>
      <div className="absolute bottom-10 right-10 w-64 h-64 bg-green-400/15 rounded-full blur-3xl animate-pulse" style={{animationDelay: '1s'}}></div>
      <div className="absolute top-1/3 right-1/4 w-48 h-48 bg-green-300/10 rounded-full blur-2xl animate-ping"></div>
      <div className="absolute bottom-1/3 left-1/4 w-56 h-56 bg-green-600/12 rounded-full blur-3xl animate-bounce" style={{animationDelay: '2s', animationDuration: '4s'}}></div>
      
      <Card className="w-full max-w-md mx-4 bg-gray-900/80 backdrop-blur-lg border-green-500/30 shadow-2xl shadow-green-500/20">
        <CardHeader className="text-center">
          <CardTitle className="brand-text text-3xl mb-2">CareerCortex</CardTitle>
          <CardDescription className="dynamic-text text-green-300 text-lg">Sign in to your account</CardDescription>
        </CardHeader>
        
        <form onSubmit={handleSubmit}>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="username" className="dynamic-text text-gray-300 font-medium">Username</Label>
              <Input
                id="username"
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="bg-gray-800/50 border-green-500/30 text-white placeholder-gray-400 focus:border-green-500 focus:ring-green-500/20 transition-all duration-300"
                placeholder="Enter your username"
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="password" className="dynamic-text text-gray-300 font-medium">Password</Label>
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="bg-gray-800/50 border-green-500/30 text-white placeholder-gray-400 focus:border-green-500 focus:ring-green-500/20 transition-all duration-300"
                placeholder="Enter your password"
                required
              />
            </div>
          </CardContent>
          
          <CardFooter className="flex flex-col space-y-4">
            <Button 
              type="submit" 
              className="w-full bg-green-600 hover:bg-green-500 text-white font-semibold py-3 rounded-lg transition-all duration-300 transform hover:scale-105 hover:shadow-lg hover:shadow-green-500/50"
            >
              Sign In
            </Button>
            
            <div className="text-center">
              <span className="dynamic-text text-gray-400">New user? </span>
              <button 
                type="button" 
                onClick={onShowSignUp}
                className="dynamic-text text-green-400 hover:text-green-300 font-medium transition-colors duration-200 hover:underline"
              >
                Create Account
              </button>
            </div>
          </CardFooter>
        </form>
      </Card>
    </div>
  );
};

export default SignInForm;