import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Trophy, Star, RotateCcw, Home } from 'lucide-react';

interface InterviewCompleteProps {
  onRestart: () => void;
  onHome: () => void;
}

const InterviewComplete: React.FC<InterviewCompleteProps> = ({ onRestart, onHome }) => {
  const overallScore = 8.2;
  const totalQuestions = 5;
  
  const getScoreColor = (score: number) => {
    if (score >= 8) return 'text-green-400';
    if (score >= 6) return 'text-yellow-400';
    return 'text-red-400';
  };

  const getScoreEmoji = (score: number) => {
    if (score >= 8) return '🎉';
    if (score >= 6) return '👍';
    return '💪';
  };

  return (
    <div className="min-h-screen bg-black relative overflow-hidden">
      {/* Background effects */}
      <div className="absolute top-20 left-20 w-96 h-96 bg-green-500/10 rounded-full blur-3xl animate-pulse"></div>
      <div className="absolute bottom-20 right-20 w-80 h-80 bg-green-400/10 rounded-full blur-3xl animate-pulse" style={{animationDelay: '1s'}}></div>
      
      <div className="relative z-10 max-w-4xl mx-auto px-4 py-12">
        <div className="text-center mb-12">
          <h1 className="brand-text text-4xl mb-4">CareerCortex</h1>
          <p className="dynamic-text text-gray-300 text-lg">Interview Complete!</p>
        </div>

        <Card className="bg-gray-900/80 backdrop-blur-lg border-green-500/30 shadow-2xl">
          <CardHeader>
            <CardTitle className="dynamic-text text-2xl text-white flex items-center justify-center">
              <Trophy className="w-8 h-8 mr-3 text-yellow-400" />
              Congratulations!
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-8">
            <div className="text-center">
              <div className="text-6xl mb-4">{getScoreEmoji(overallScore)}</div>
              <h2 className={`dynamic-text text-4xl font-bold mb-2 ${getScoreColor(overallScore)}`}>
                {overallScore}/10
              </h2>
              <p className="dynamic-text text-gray-300 text-lg">Overall Score</p>
            </div>

            <div className="grid md:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="bg-gray-800/50 rounded-lg p-4">
                  <Star className="w-8 h-8 text-yellow-400 mx-auto mb-2" />
                  <h3 className="dynamic-text text-white font-semibold">Questions Answered</h3>
                  <p className="dynamic-text text-2xl text-green-400 font-bold">{totalQuestions}</p>
                </div>
              </div>
              
              <div className="text-center">
                <div className="bg-gray-800/50 rounded-lg p-4">
                  <Trophy className="w-8 h-8 text-green-400 mx-auto mb-2" />
                  <h3 className="dynamic-text text-white font-semibold">Performance</h3>
                  <p className="dynamic-text text-2xl text-green-400 font-bold">
                    {overallScore >= 8 ? 'Excellent' : overallScore >= 6 ? 'Good' : 'Needs Work'}
                  </p>
                </div>
              </div>
              
              <div className="text-center">
                <div className="bg-gray-800/50 rounded-lg p-4">
                  <Star className="w-8 h-8 text-purple-400 mx-auto mb-2" />
                  <h3 className="dynamic-text text-white font-semibold">Improvement</h3>
                  <p className="dynamic-text text-sm text-gray-300">
                    {overallScore >= 8 ? 'Keep it up!' : 'Practice more!'}
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-gray-800/30 rounded-lg p-6">
              <h3 className="dynamic-text text-xl text-white mb-4 text-center">Key Takeaways</h3>
              <div className="space-y-2">
                <p className="dynamic-text text-gray-300 flex items-center">
                  <span className="w-2 h-2 bg-green-400 rounded-full mr-3"></span>
                  Strong technical knowledge demonstrated
                </p>
                <p className="dynamic-text text-gray-300 flex items-center">
                  <span className="w-2 h-2 bg-yellow-400 rounded-full mr-3"></span>
                  Consider practicing more complex scenarios
                </p>
                <p className="dynamic-text text-gray-300 flex items-center">
                  <span className="w-2 h-2 bg-blue-400 rounded-full mr-3"></span>
                  Good communication and explanation skills
                </p>
              </div>
            </div>

            <div className="flex gap-4">
              <Button 
                onClick={onRestart}
                className="flex-1 bg-blue-600 hover:bg-blue-500 text-white font-semibold py-3 rounded-lg transition-all duration-300 transform hover:scale-105"
              >
                <RotateCcw className="w-4 h-4 mr-2" />
                Try Another Interview
              </Button>
              
              <Button 
                onClick={onHome}
                className="flex-1 bg-green-600 hover:bg-green-500 text-white font-semibold py-3 rounded-lg transition-all duration-300 transform hover:scale-105"
              >
                <Home className="w-4 h-4 mr-2" />
                Back to Dashboard
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default InterviewComplete;