import React, { useState } from 'react';
import ResumeUpload from './ResumeUpload';
import InterviewTips from './InterviewTips';
import InterviewSession from './InterviewSession';
import InterviewComplete from './InterviewComplete';

interface InterviewFlowProps {
  onBackToDashboard: () => void;
}

type FlowStep = 'upload' | 'tips' | 'interview' | 'complete';

const InterviewFlow: React.FC<InterviewFlowProps> = ({ onBackToDashboard }) => {
  const [currentStep, setCurrentStep] = useState<FlowStep>('upload');
  const [interviewType, setInterviewType] = useState('');
  const [resumeContent, setResumeContent] = useState('');

  const handleInterviewTypeSelect = (type: string, content: string) => {
    setInterviewType(type);
    setResumeContent(content);
    setCurrentStep('tips');
  };

  const handleStartInterview = () => {
    setCurrentStep('interview');
  };

  const handleInterviewComplete = () => {
    setCurrentStep('complete');
  };

  const handleRestart = () => {
    setCurrentStep('upload');
    setInterviewType('');
    setResumeContent('');
  };

  const renderCurrentStep = () => {
    switch (currentStep) {
      case 'upload':
        return <ResumeUpload onInterviewTypeSelect={handleInterviewTypeSelect} />;
      case 'tips':
        return (
          <InterviewTips 
            interviewType={interviewType} 
            onStartInterview={handleStartInterview} 
          />
        );
      case 'interview':
        return (
          <InterviewSession 
            interviewType={interviewType}
            resumeContent={resumeContent}
            onComplete={handleInterviewComplete}
          />
        );
      case 'complete':
        return (
          <InterviewComplete 
            onRestart={handleRestart}
            onHome={onBackToDashboard}
          />
        );
      default:
        return <ResumeUpload onInterviewTypeSelect={handleInterviewTypeSelect} />;
    }
  };

  return renderCurrentStep();
};

export default InterviewFlow;