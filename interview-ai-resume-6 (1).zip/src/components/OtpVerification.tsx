import React, { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';

interface OtpVerificationProps {
  onVerify: (otp: string) => void;
  onResend: () => void;
  phone: string;
}

const OtpVerification: React.FC<OtpVerificationProps> = ({ onVerify, onResend, phone }) => {
  const [otp, setOtp] = useState(['', '', '', '', '', '']);
  const [isAnimating, setIsAnimating] = useState(false);
  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);

  useEffect(() => {
    if (inputRefs.current[0]) {
      inputRefs.current[0].focus();
    }
  }, []);

  const handleChange = (index: number, value: string) => {
    if (value.length > 1) return;
    
    const newOtp = [...otp];
    newOtp[index] = value;
    setOtp(newOtp);

    if (value && index < 5 && inputRefs.current[index + 1]) {
      inputRefs.current[index + 1]?.focus();
    }

    if (newOtp.every(digit => digit !== '') && newOtp.join('').length === 6) {
      setIsAnimating(true);
      setTimeout(() => {
        onVerify(newOtp.join(''));
        setIsAnimating(false);
      }, 500);
    }
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent) => {
    if (e.key === 'Backspace' && !otp[index] && index > 0) {
      inputRefs.current[index - 1]?.focus();
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const otpString = otp.join('');
    if (otpString.length === 6) {
      setIsAnimating(true);
      setTimeout(() => {
        onVerify(otpString);
        setIsAnimating(false);
      }, 500);
    }
  };

  return (
    <div className="min-h-screen bg-black relative overflow-hidden flex items-center justify-center">
      {/* Background glow effects */}
      <div className="absolute top-16 left-16 w-96 h-96 bg-green-500/20 rounded-full blur-3xl animate-pulse"></div>
      <div className="absolute bottom-16 right-16 w-80 h-80 bg-green-400/15 rounded-full blur-3xl animate-pulse" style={{animationDelay: '1s'}}></div>
      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-72 h-72 bg-green-300/10 rounded-full blur-2xl animate-ping"></div>
      
      <Card className={`w-full max-w-md mx-4 bg-gray-900/80 backdrop-blur-lg border-green-500/30 shadow-2xl shadow-green-500/20 transition-all duration-500 ${isAnimating ? 'scale-105 shadow-green-500/40' : ''}`}>
        <CardHeader className="text-center">
          <CardTitle className="brand-text text-3xl mb-2">Verify Your Phone</CardTitle>
          <CardDescription className="dynamic-text text-green-300 text-lg">
            Enter the 6-digit code sent to
            <br />
            <span className="font-semibold text-white">{phone}</span>
          </CardDescription>
        </CardHeader>
        
        <form onSubmit={handleSubmit}>
          <CardContent className="space-y-8">
            <div className="flex justify-center space-x-3">
              {otp.map((digit, index) => (
                <input
                  key={index}
                  ref={(el) => (inputRefs.current[index] = el)}
                  type="text"
                  inputMode="numeric"
                  pattern="[0-9]*"
                  maxLength={1}
                  value={digit}
                  onChange={(e) => handleChange(index, e.target.value.replace(/\D/g, ''))}
                  onKeyDown={(e) => handleKeyDown(index, e)}
                  className={`w-12 h-12 text-center text-xl font-bold rounded-lg bg-gray-800/50 border-green-500/30 text-white focus:border-green-500 focus:ring-green-500/20 transition-all duration-300 ${digit ? 'border-green-500 bg-green-500/10' : ''} ${isAnimating ? 'animate-pulse' : ''}`}
                />
              ))}
            </div>
            
            <div className="text-center">
              <p className="dynamic-text text-gray-400 text-sm mb-4">
                Didn't receive the code?
              </p>
              <Button 
                type="button" 
                variant="ghost" 
                onClick={onResend}
                className="dynamic-text text-green-400 hover:text-green-300 hover:bg-green-500/10 transition-all duration-300"
              >
                Resend Code
              </Button>
            </div>
          </CardContent>
          
          <CardFooter>
            <Button 
              type="submit" 
              disabled={otp.join('').length !== 6}
              className={`w-full bg-green-600 hover:bg-green-500 text-white font-semibold py-3 rounded-lg transition-all duration-300 transform hover:scale-105 hover:shadow-lg hover:shadow-green-500/50 disabled:opacity-50 disabled:cursor-not-allowed ${isAnimating ? 'animate-pulse' : ''}`}
            >
              {isAnimating ? 'Verifying...' : 'Verify Code'}
            </Button>
          </CardFooter>
        </form>
      </Card>
    </div>
  );
};

export default OtpVerification;