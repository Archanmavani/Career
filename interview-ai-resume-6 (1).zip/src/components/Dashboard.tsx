import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { MessageSquare, LogOut, Play, Brain, Users, Code } from 'lucide-react';
import InterviewFlow from './InterviewFlow';

interface DashboardProps {
  username: string;
  onLogout: () => void;
}

const Dashboard: React.FC<DashboardProps> = ({ username, onLogout }) => {
  const [showInterviewFlow, setShowInterviewFlow] = useState(false);

  if (showInterviewFlow) {
    return <InterviewFlow onBackToDashboard={() => setShowInterviewFlow(false)} />;
  }

  return (
    <div className="min-h-screen bg-black relative overflow-hidden">
      {/* Background glow effects */}
      <div className="absolute top-20 left-20 w-96 h-96 bg-green-500/10 rounded-full blur-3xl animate-pulse"></div>
      <div className="absolute bottom-20 right-20 w-80 h-80 bg-green-400/10 rounded-full blur-3xl animate-pulse" style={{animationDelay: '1s'}}></div>
      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-green-300/5 rounded-full blur-3xl animate-pulse" style={{animationDelay: '2s'}}></div>
      
      {/* Header */}
      <div className="relative z-10 bg-gray-900/50 backdrop-blur-lg border-b border-green-500/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div>
              <h1 className="brand-text text-3xl">CareerCortex</h1>
              <p className="dynamic-text text-green-300">Welcome back, {username}!</p>
            </div>
            <Button 
              onClick={onLogout}
              variant="ghost"
              className="text-red-400 hover:text-red-300 hover:bg-red-500/10 transition-all duration-300"
            >
              <LogOut className="w-4 h-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="relative z-10 max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-12">
          <h2 className="dynamic-text text-4xl text-white mb-4">AI-Powered Interview Practice</h2>
          <p className="dynamic-text text-gray-300 text-lg">Enhance your interview skills with personalized AI feedback</p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 mb-12">
          {/* Start Interview Card */}
          <Card className="bg-gray-900/80 backdrop-blur-lg border-green-500/30 shadow-2xl shadow-green-500/20">
            <CardHeader>
              <CardTitle className="dynamic-text text-2xl text-white flex items-center">
                <Play className="w-6 h-6 mr-2 text-green-400" />
                Start Interview Practice
              </CardTitle>
              <CardDescription className="dynamic-text text-gray-300">
                Upload your resume and begin AI-powered interview practice
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button 
                onClick={() => setShowInterviewFlow(true)}
                className="w-full bg-green-600 hover:bg-green-500 text-white font-semibold py-4 rounded-lg transition-all duration-300 transform hover:scale-105 hover:shadow-lg hover:shadow-green-500/50"
              >
                Begin Interview Practice
              </Button>
            </CardContent>
          </Card>

          {/* Features Card */}
          <Card className="bg-gray-900/80 backdrop-blur-lg border-green-500/30 shadow-2xl shadow-green-500/20">
            <CardHeader>
              <CardTitle className="dynamic-text text-2xl text-white flex items-center">
                <MessageSquare className="w-6 h-6 mr-2 text-green-400" />
                AI Interview Features
              </CardTitle>
              <CardDescription className="dynamic-text text-gray-300">
                Powered by advanced AI technology
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-green-400 rounded-full mt-2"></div>
                  <div>
                    <h4 className="dynamic-text text-white font-medium">Resume Analysis</h4>
                    <p className="dynamic-text text-gray-400 text-sm">AI analyzes your resume to understand your background</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-green-400 rounded-full mt-2"></div>
                  <div>
                    <h4 className="dynamic-text text-white font-medium">Speech Recognition</h4>
                    <p className="dynamic-text text-gray-400 text-sm">Voice-to-text conversion for natural responses</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-green-400 rounded-full mt-2"></div>
                  <div>
                    <h4 className="dynamic-text text-white font-medium">Real-time Feedback</h4>
                    <p className="dynamic-text text-gray-400 text-sm">Get instant feedback with ratings and suggestions</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Interview Types */}
        <div className="grid md:grid-cols-3 gap-6">
          <Card className="bg-gray-900/60 backdrop-blur-lg border-blue-500/30 shadow-xl">
            <CardHeader className="text-center">
              <Code className="w-12 h-12 mx-auto mb-4 text-blue-400" />
              <CardTitle className="dynamic-text text-xl text-white">Technical Interview</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="dynamic-text text-gray-300 text-center text-sm">Programming, algorithms, and technical skills assessment</p>
            </CardContent>
          </Card>

          <Card className="bg-gray-900/60 backdrop-blur-lg border-green-500/30 shadow-xl">
            <CardHeader className="text-center">
              <Users className="w-12 h-12 mx-auto mb-4 text-green-400" />
              <CardTitle className="dynamic-text text-xl text-white">HR Interview</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="dynamic-text text-gray-300 text-center text-sm">Behavioral questions and soft skills evaluation</p>
            </CardContent>
          </Card>

          <Card className="bg-gray-900/60 backdrop-blur-lg border-purple-500/30 shadow-xl">
            <CardHeader className="text-center">
              <Brain className="w-12 h-12 mx-auto mb-4 text-purple-400" />
              <CardTitle className="dynamic-text text-xl text-white">Test Case Interview</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="dynamic-text text-gray-300 text-center text-sm">Problem-solving and analytical thinking challenges</p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;