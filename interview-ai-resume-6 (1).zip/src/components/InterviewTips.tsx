import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Lightbulb, CheckCircle, ArrowRight } from 'lucide-react';

interface InterviewTipsProps {
  interviewType: string;
  onStartInterview: () => void;
}

const InterviewTips: React.FC<InterviewTipsProps> = ({ interviewType, onStartInterview }) => {
  const getTips = () => {
    switch (interviewType) {
      case 'technical':
        return {
          title: 'Technical Interview Tips',
          tips: [
            'Review fundamental programming concepts and data structures',
            'Practice coding problems on platforms like LeetCode or HackerRank',
            'Understand time and space complexity analysis',
            'Be prepared to explain your thought process while coding',
            'Review system design basics for senior positions',
            'Practice whiteboard coding or screen sharing'
          ]
        };
      case 'hr':
        return {
          title: 'HR Interview Tips',
          tips: [
            'Prepare STAR method examples (Situation, Task, Action, Result)',
            'Research the company culture and values thoroughly',
            'Practice answering "Tell me about yourself" concisely',
            'Prepare questions to ask about the role and company',
            'Be honest about strengths and areas for improvement',
            'Show enthusiasm and genuine interest in the position'
          ]
        };
      case 'testcase':
        return {
          title: 'Test Case Interview Tips',
          tips: [
            'Think through edge cases and boundary conditions',
            'Consider both positive and negative test scenarios',
            'Break down complex problems into smaller components',
            'Explain your testing strategy clearly',
            'Consider user experience and real-world usage',
            'Practice writing clear and comprehensive test cases'
          ]
        };
      default:
        return { title: 'Interview Tips', tips: [] };
    }
  };

  const { title, tips } = getTips();

  return (
    <div className="min-h-screen bg-black relative overflow-hidden">
      {/* Background effects */}
      <div className="absolute top-20 left-20 w-96 h-96 bg-green-500/10 rounded-full blur-3xl animate-pulse"></div>
      <div className="absolute bottom-20 right-20 w-80 h-80 bg-green-400/10 rounded-full blur-3xl animate-pulse" style={{animationDelay: '1s'}}></div>
      
      <div className="relative z-10 max-w-4xl mx-auto px-4 py-12">
        <div className="text-center mb-12">
          <h1 className="brand-text text-4xl mb-4">CareerCortex</h1>
          <p className="dynamic-text text-gray-300 text-lg">Interview Preparation Tips</p>
        </div>

        <Card className="bg-gray-900/80 backdrop-blur-lg border-green-500/30 shadow-2xl">
          <CardHeader>
            <CardTitle className="dynamic-text text-2xl text-white flex items-center justify-center">
              <Lightbulb className="w-6 h-6 mr-2 text-yellow-400" />
              {title}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-4">
              {tips.map((tip, index) => (
                <div key={index} className="flex items-start space-x-3">
                  <CheckCircle className="w-5 h-5 text-green-400 mt-0.5 flex-shrink-0" />
                  <p className="dynamic-text text-gray-300">{tip}</p>
                </div>
              ))}
            </div>
            
            <div className="pt-6">
              <Button 
                onClick={onStartInterview}
                className="w-full bg-green-600 hover:bg-green-500 text-white font-semibold py-3 rounded-lg transition-all duration-300 transform hover:scale-105 hover:shadow-lg hover:shadow-green-500/50"
              >
                Start Interview
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default InterviewTips;