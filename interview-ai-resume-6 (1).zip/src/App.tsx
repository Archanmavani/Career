import React, { useEffect, useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { ThemeProvider } from '@/components/theme-provider';
import { Toaster } from '@/components/ui/sonner';
import { AppProvider } from '@/contexts/AppContext';
import AuthManager from '@/components/AuthManager';
import Dashboard from '@/components/Dashboard';
import GetStartedPage from '@/components/GetStartedPage';
import NotFound from '@/pages/NotFound';

function App() {
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [username, setUsername] = useState('');
  const [showGetStarted, setShowGetStarted] = useState(true);

  useEffect(() => {
    const updateMousePosition = (e: MouseEvent) => {
      setMousePosition({ x: e.clientX, y: e.clientY });
    };

    window.addEventListener('mousemove', updateMousePosition);
    return () => window.removeEventListener('mousemove', updateMousePosition);
  }, []);

  const handleAuthSuccess = (user: string) => {
    setIsAuthenticated(true);
    setUsername(user);
    setShowGetStarted(false);
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setUsername('');
    setShowGetStarted(true);
  };

  const handleGetStarted = () => {
    setShowGetStarted(false);
  };

  return (
    <ThemeProvider defaultTheme="dark" storageKey="vite-ui-theme">
      <AppProvider>
        <div className="min-h-screen bg-black text-white">
          {/* Custom cursor */}
          <div
            className="custom-cursor"
            style={{
              left: `${mousePosition.x - 10}px`,
              top: `${mousePosition.y - 10}px`,
            }}
          />
          
          <Router>
            <Routes>
              <Route 
                path="/" 
                element={
                  showGetStarted ? (
                    <GetStartedPage onGetStarted={handleGetStarted} />
                  ) : isAuthenticated ? (
                    <Dashboard username={username} onLogout={handleLogout} />
                  ) : (
                    <AuthManager onAuthSuccess={handleAuthSuccess} />
                  )
                } 
              />
              <Route path="*" element={<NotFound />} />
            </Routes>
          </Router>
          
          <Toaster />
        </div>
      </AppProvider>
    </ThemeProvider>
  );
}

export default App;